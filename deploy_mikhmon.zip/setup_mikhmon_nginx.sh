#!/bin/bash
# setup_mikhmon_nginx.sh

echo "Installing PHP..."
apt-get update
apt-get install -y php php-fpm php-mysql php-xml php-curl php-gd php-mbstring php-zip

# Detect PHP Version for the socket
PHP_VER=$(php -r 'echo PHP_MAJOR_VERSION.".".PHP_MINOR_VERSION;')
PHP_SOCK="unix:/var/run/php/php${PHP_VER}-fpm.sock"
echo "Detected PHP $PHP_VER (Sock: $PHP_SOCK)"

echo "Configuring Nginx with PHP Support..."
cat > /etc/nginx/sites-available/default <<EOF
server {
    listen 80 default_server;
    root /var/www/wipay-client;
    index index.php login.html index.html;
    server_name _;

    location / {
        try_files \$uri \$uri/ =404;
    }

    # Mikhmon & PHP Support
    location ~ \.php$ {
        include snippets/fastcgi-php.conf;
        fastcgi_pass $PHP_SOCK;
    }

    location ~ /\.ht {
        deny all;
    }

    # WiPay API Proxy
    location /api {
        proxy_pass http://localhost:5002;
        proxy_http_version 1.1;
        proxy_set_header Upgrade \$http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host \$host;
        proxy_cache_bypass \$http_upgrade;
    }

    location /socket.io/ {
        proxy_pass http://localhost:5002;
        proxy_http_version 1.1;
        proxy_set_header Upgrade \$http_upgrade;
        proxy_set_header Connection "upgrade";
    }
}
EOF

echo "Fixing Permissions..."
chown -R www-data:www-data /var/www/wipay-client/mikhmon
chmod -R 755 /var/www/wipay-client/mikhmon

echo "Restarting Services..."
systemctl restart php${PHP_VER}-fpm
systemctl restart nginx

echo "DONE! Mikhmon should be live at /mikhmon"
